namespace WinFormsOrtalama
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        #region Buton i�lemleri
        //Buton i�lemleri
        private void button1_Click(object sender, EventArgs e)
        {
            String[] array = richTextBox1.Lines;
            int minimum = Int32.MaxValue;
            int maximum = Int32.MinValue;
            int toplam = 0;
            foreach(string sayi in array)
            {
                int deger = Convert.ToInt32(sayi);
                toplam += deger;
                if (deger > maximum) maximum = deger;
                if (deger < minimum) minimum = deger;
            }

            string ortalama = Convert.ToString(toplam/array.Length);
            string minimumStr = Convert.ToString(minimum);
            string maximumStr = Convert.ToString(maximum);

            labelMin.Text = minimumStr;
            labelMax.Text = maximumStr;
            labelOrtalama.Text = ortalama;

        }

        private void button2_Click(object sender, EventArgs e)
        {
            String[] array = richTextBox1.Lines;
            int minimum = Int32.MaxValue;
            int maximum = Int32.MinValue;
            int toplam = 0;
           for(int i=0, b=0; i < array.Length; i++)
            {
                string sayi = array[i];
                int deger = Convert.ToInt32(sayi);
                toplam += deger;
                if (deger > maximum) { maximum = deger; b = i; }
                if (deger < minimum) minimum = deger;

                if (b > array.Length / 2) MessageBox.Show("En b�y�k eleman sa� tarafta");
            }

           
            string ortalama = Convert.ToString(toplam / array.Length);
            string minimumStr = Convert.ToString(minimum);
            string maximumStr = Convert.ToString(maximum);

            labelMin.Text = minimumStr;
            labelMax.Text = maximumStr;
            labelOrtalama.Text = ortalama;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            String[] array = richTextBox1.Lines;
            List<string> list = new List<string>(array);
            string ilkYuzdegeri = list.Find(x => x.Equals("100"));
            MessageBox.Show(ilkYuzdegeri);
        }
        #endregion
    }
}