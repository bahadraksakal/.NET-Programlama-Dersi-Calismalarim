using MySqlConnector;

namespace WinTableGrid
{
    public partial class Form1 : Form
    {

        private List<String[]> changedRows = new List<string[]>();

        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                
                mySqlConnection1.Open();
                MySqlDataReader reader =  mySqlCommand1.ExecuteReader();
                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        int urunID = reader.GetInt32(0);
                        string urunAdi = reader.GetString(1);
                        string urunMiktari = reader.GetString(2);
                        string urunBirimi = reader.GetString(3);
                        string urunKategorisi = reader.GetString(4);
                        dataGridView1.Rows.Add(new string[4] { urunID.ToString(), urunAdi, urunMiktari, urunKategorisi });
                    }
                }

                reader.Close();
                mySqlConnection1.Close();

            }
            catch(Exception ex)
            {

            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if(changedRows.Count > 0)
            {
                
                foreach (string[] rows in changedRows)
                {
                    MySqlCommand updateCommand = mySqlConnection1.CreateCommand();
                    mySqlConnection1.Open();

                    updateCommand.CommandText = "UPDATE uruntablosu(urunadi, urunmiktari, urunkategorisi) " +
                        "VALUES (@adi, @miktari, @kategorisi) WHERE id=" + rows[0];
                    
                    updateCommand.Parameters.AddWithValue("adi", rows[1]);
                    updateCommand.Parameters.AddWithValue("miktari", rows[2]);
                    updateCommand.Parameters.AddWithValue("kategorisi", rows[3]);

                    updateCommand.ExecuteNonQuery();
                    mySqlConnection1.Close();
                }
            }
        }

        private void dataGridView1_CellValueChanged(object sender, DataGridViewCellEventArgs e)
        {
            int rowIndex = e.RowIndex;
            DataGridViewCellCollection rowCells = dataGridView1.Rows[rowIndex].Cells;
            changedRows.Add(new string[] { rowCells[0].ToString(), rowCells[1].ToString(), rowCells[2].ToString(), rowCells[3].ToString(), rowCells[4].ToString()});
        }
    }
}