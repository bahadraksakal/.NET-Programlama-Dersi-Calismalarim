﻿using MySqlConnector;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Collections.Specialized.BitVector32;

namespace MySQLDataGridExample
{
    public partial class Form1 : Form
    {
        bool loadingStopped = false;
        string[] columnNames = new string[] {"id","urunadi","urunkategorisi","urunmiktari"}; 
        List<DatabaseUpdate> updates = new List<DatabaseUpdate>();
        object currentValue = null;

        public Form1()
        {
            
            InitializeComponent();

        }

        static string read()
        {
            string connectionString = ConfigurationManager.ConnectionStrings["MySQL"].ConnectionString;
            return connectionString;
        }

        static void encrypt(string exeFile)
        {
            // Takes the executable file name without the
            // .config extension.
            
            try
            {
                // Open the configuration file and retrieve
                // the connectionStrings section.
                // Save the current configuration.
                Configuration configuration = ConfigurationManager.OpenExeConfiguration(exeFile);
                var section = configuration.GetSection("connectionStrings") as ConnectionStringsSection;
                
                section.ConnectionStrings[0].ConnectionString = "localhost";
                
                    // Şifrelemeye başla.
               section.SectionInformation.ForceSave = true;
               section.SectionInformation.ProtectSection("DataProtectionConfigurationProvider");
                
                configuration.SaveAs("App.config");
                MessageBox.Show(section.SectionInformation.IsProtected.ToString());
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
           
           
            
        }

        public bool test()
        {
            try
            {
                mySqlConnection1.Open();
                mySqlConnection1.Close();
                return true;
            }
            catch
            {
                Console.WriteLine("Hata");
                return false;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (test())
            {
                label1.Text = "Bağlantı kuruldu.";
            }
            else
            {
                label1.Text = "Bağlantı kurulamadı.";
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            mySqlConnection1.Open();
            MySqlDataReader reader = mySqlCommand1.ExecuteReader();
            while (reader.Read())
            {
                int urunID = reader.GetInt32(0);
                string urunAdi = reader.GetString(1);
                int urunMiktari = reader.GetInt32(2);
                string urunKategori = reader.GetString(4);

                dataGridView1.Rows.Add(new object[] {urunID, urunAdi, urunKategori, urunMiktari});
            }

            mySqlConnection1.Close();
            loadingStopped = true;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            foreach (DatabaseUpdate update in updates)
            {
                update.run(mySqlConnection1);
            }
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (loadingStopped) { 
              currentValue = dataGridView1.Rows[e.RowIndex].Cells[e.ColumnIndex].Value;
            }
        }

        private void dataGridView1_CellValueChanged(object sender, DataGridViewCellEventArgs e)
        {
            if (loadingStopped) {
                object newValue = dataGridView1.Rows[e.RowIndex].Cells[e.ColumnIndex].Value;
                DatabaseUpdate update = new DatabaseUpdate();
                update.oncekiDeger = currentValue;
                update.privateKey = Convert.ToInt32(dataGridView1.Rows[e.RowIndex].Cells[0].Value);
                update.yeniDeger = newValue;
                update.columnAdi = columnNames[e.ColumnIndex];
                updates.Add(update);
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            DatabaseUpdate update = updates.Last();
            update.revert();
            update.run(mySqlConnection1);
            
            for(int i = 0; i < dataGridView1.Rows.Count; i++)
            {
                int privateKey = Convert.ToInt32(dataGridView1.Rows[i].Cells[0].Value);
                int columnIndex = update.columnIndex(columnNames);
                if (privateKey == update.privateKey)
                {
                    loadingStopped = false;
                    dataGridView1.Rows[i].Cells[columnIndex].Value = update.yeniDeger;

                    
                    break;
                }
            }

            dataGridView1.Update();
            loadingStopped = true;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            string appFile = @"App.config";
            string connStr = read();
            mySqlConnection1.ConnectionString = connStr;
            label2.Text = connStr;
        }

        private void button5_Click(object sender, EventArgs e)
        {
            encrypt("App.config");
        }
    }

    
}
