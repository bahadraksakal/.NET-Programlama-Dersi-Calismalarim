namespace WinFormsDonusum
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private string donustur(object dolar)
        {
            string sayiStr = dolar as string;
            float sayiFloat = float.Parse(sayiStr);
            float sayi = sayiFloat * 18.56f;
            return sayi.ToString();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string deger = textBox1.Text;
            object sayi = deger as object;
            label1.Text = donustur(sayi);

            for(char a; ;)
            {
                
            }
        }
    }
}