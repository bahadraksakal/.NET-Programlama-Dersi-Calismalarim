namespace WinFormsClass
{
    public partial class Form1 : Form
    {
        private delegate string islem(string i, string y);
        private islem islemler;
        
        public Form1()
        {
            InitializeComponent();

            islemler += topla;
            islemler += carp;
        }

        private string topla(string x, string y)
        {
            return (Convert.ToInt32(x) + Convert.ToInt32(y)).ToString();
        }

        private string carp(string x, string y)
        {
            return (Convert.ToInt32(x) * Convert.ToInt32(y)).ToString();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            panel1.Enabled = false;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            panel1.Top = flowLayoutPanel1.Top + button4.Top;
            panel1.Height = button4.Height;

            string deger = islemler(textBox1.Text, textBox2.Text);
            textBox3.Text = deger;

        }

        private void button2_Click(object sender, EventArgs e)
        {
            panel1.Top = flowLayoutPanel1.Top + button2.Top;
            panel1.Height = button2.Height;

        }

        private void button3_Click(object sender, EventArgs e)
        {
            panel1.Top = flowLayoutPanel1.Top + button3.Top;
            panel1.Height = button3.Height;
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}