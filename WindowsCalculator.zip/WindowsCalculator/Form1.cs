﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsCalculator
{
    public partial class Form1 : Form
    {
        private bool isIlk = true;
        private int hesaplanan = 0, simdiki = 0;
        private string islem = "+";
        public Form1()
        {
            InitializeComponent();
        }

        private int getSayi(string text)
        {
            int sayi;
            Int32.TryParse(text, out sayi);
            return sayi;
        }

        private string getIslem(string text)
        {
            if (text.Length == 1)
            {
                return text;
            }
            else if (text.Length > 1)
            {
                return text.Substring(text.Length - 1);
            }
            else return "";
        }


        private bool isSayi(string text)
        {
            int sayi;
            return Int32.TryParse(text, out sayi);
        }

        private bool isSembol(string text)
        {

            return (text == "+" || text == "-");
        }

        private bool isSembolSon(string text)
        {
            return (text.EndsWith("+")||text.EndsWith("-")|| text.StartsWith("+") || text.StartsWith("-"));
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if(islem == "+")
            {
                int yeniHesaplanan = hesaplanan + simdiki;
                textBox1.Text = "";
                label2.Text = yeniHesaplanan.ToString();
                hesaplanan = yeniHesaplanan;
                simdiki = 0;
                islem = "";
                isIlk = false;
            }
            else if(islem == "-")
            {
                int yeniHesaplanan = hesaplanan - simdiki;
                textBox1.Text = "";
                label2.Text = yeniHesaplanan.ToString();
                hesaplanan = yeniHesaplanan;
                simdiki = 0;
                islem = "";
                isIlk = false;
            }
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            if(isSayi(textBox1.Text) || isSembolSon(textBox1.Text))
            {
                if (isSayi(textBox1.Text))
                {
                    simdiki = getSayi(textBox1.Text);

                }
                else if (isSembolSon(textBox1.Text))
                {
                    if (isIlk)
                    {
                        hesaplanan = simdiki;
                    }

                    islem = getIslem(textBox1.Text);
                    label2.Text = hesaplanan.ToString() + islem;
                    textBox1.Text = "";
                }
                
            }
            else
            {
                textBox1.Text = "";
            }
        }
    }
}
