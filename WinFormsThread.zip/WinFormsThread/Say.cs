﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WinFormsThread
{
    
    internal class Say
    {
        private RichTextBox component;

        public Say setComponent(RichTextBox component)
        {
            this.component = component;
            return this;
        }
        void saymaFunction()
        {
            Random rnd = new Random();
            string sayi = rnd.NextInt64().ToString();
            List<string> lineList = component.Lines.ToList();
            lineList.Add(sayi);
            component.Lines = lineList.ToArray();
        }

        public void saymaDonguThread()
        {
            while (true)
            {
                saymaFunction();
            }
        }


    }
}
