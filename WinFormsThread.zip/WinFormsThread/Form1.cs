using System.ComponentModel;

namespace WinFormsThread
{
    public partial class Form1 : Form
    {
        
        private Thread sayThread;
        private bool sayDevam = true;
        
        public Form1()
        {
            CheckForIllegalCrossThreadCalls = false;
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            sayDevam = true;
            sayThread = new Thread(saymaDonguThread);

            sayThread.Start();
            //saymaDonguThread();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            sayDevam = false;
            
       

        }

        public void saymaFunction()
        {
            Random rnd = new Random();
            string sayi = rnd.NextInt64().ToString();
            List<string> list = richTextBox1.Lines.ToList();
            list.Add(sayi);
            richTextBox1.Lines = list.ToArray();
            Thread.Sleep(1000);
        }

        public void saymaDonguThread()
        {
            while (sayDevam)
            {
                saymaFunction();
            }
        }
    }
}