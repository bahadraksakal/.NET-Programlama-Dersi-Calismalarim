﻿using MySqlConnector;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MySQLDataGridExample
{
    internal class DatabaseUpdate
    {
        public object oncekiDeger;
        public object yeniDeger;

        public string columnAdi;
        public int privateKey = 0;

        public void run(MySqlConnection connection)
        {
            connection.Open();
            MySqlCommand command = connection.CreateCommand();
            
            command.CommandText = "UPDATE uruntablosu SET "+columnAdi+"=@deger WHERE id=" + privateKey;
            command.Parameters.AddWithValue("deger", yeniDeger);
            int value = command.ExecuteNonQuery();
            connection.Close();
        }



        public void revert()
        {
            object swap = oncekiDeger;
            oncekiDeger = yeniDeger;
            yeniDeger = swap;
        }

        public int columnIndex(string[] tabloKolonAdlari)
        {
            int index = 0;
            while(index < tabloKolonAdlari.Length)
            {
                if(tabloKolonAdlari[index] == columnAdi) { return index; }
                index++;
            }

            return -1;
        }
    }
}
