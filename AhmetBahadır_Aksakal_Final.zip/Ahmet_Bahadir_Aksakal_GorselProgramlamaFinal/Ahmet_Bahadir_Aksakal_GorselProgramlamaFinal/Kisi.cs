﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ahmet_Bahadir_Aksakal_GorselProgramlamaFinal
{
    internal class Kisi
    {
        string ad;
        string soyAd;
        string tel;

        public Kisi(string ad, string soyAd, string tel)
        {
            this.ad = ad;
            this.soyAd = soyAd;
            this.tel = tel;
        }
    }
}
