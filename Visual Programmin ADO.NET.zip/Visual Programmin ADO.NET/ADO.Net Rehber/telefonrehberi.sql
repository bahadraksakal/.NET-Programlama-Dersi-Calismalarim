-- phpMyAdmin SQL Dump
-- version 4.1.6
-- http://www.phpmyadmin.net
--
-- Anamakine: 127.0.0.1
-- Üretim Zamanı: 22 May 2014, 10:35:36
-- Sunucu sürümü: 5.6.16
-- PHP Sürümü: 5.5.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Veritabanı: `telefonrehberi`
--

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `bolum`
--

CREATE TABLE IF NOT EXISTS `bolum` (
  `bolum_id` int(11) NOT NULL AUTO_INCREMENT,
  `bolum_adi` varchar(20) NOT NULL,
  PRIMARY KEY (`bolum_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin5 AUTO_INCREMENT=4 ;

--
-- Tablo döküm verisi `bolum`
--

INSERT INTO `bolum` (`bolum_id`, `bolum_adi`) VALUES
(1, 'Bilgisayar'),
(2, 'Muhasebe'),
(3, 'Halkla İlişkiler');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `kullanici`
--

CREATE TABLE IF NOT EXISTS `kullanici` (
  `kul_id` int(11) NOT NULL AUTO_INCREMENT,
  `kul_adi` varchar(20) NOT NULL,
  `sifre` varchar(20) NOT NULL,
  `rol` varchar(1) NOT NULL,
  PRIMARY KEY (`kul_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin5 AUTO_INCREMENT=4 ;

--
-- Tablo döküm verisi `kullanici`
--

INSERT INTO `kullanici` (`kul_id`, `kul_adi`, `sifre`, `rol`) VALUES
(1, 'admin', '123', 'A'),
(2, 'user', '123', 'G'),
(3, 'demo', '123', 'D');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `rehber`
--

CREATE TABLE IF NOT EXISTS `rehber` (
  `rehber_id` int(11) NOT NULL AUTO_INCREMENT,
  `ad` varchar(20) NOT NULL,
  `soyad` varchar(20) NOT NULL,
  `bolum_id` int(11) NOT NULL,
  `silindimi` tinyint(1) NOT NULL DEFAULT '0',
  `yaratma_tarihi` datetime NOT NULL,
  `degistirme_tarihi` datetime NOT NULL,
  PRIMARY KEY (`rehber_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin5 AUTO_INCREMENT=6 ;

--
-- Tablo döküm verisi `rehber`
--

INSERT INTO `rehber` (`rehber_id`, `ad`, `soyad`, `bolum_id`, `silindimi`, `yaratma_tarihi`, `degistirme_tarihi`) VALUES
(1, 'Metin 2', 'Tekin', 1, 0, '0000-00-00 00:00:00', '2014-05-22 11:28:40'),
(2, 'Feyyaz', 'Uçar', 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(3, 'Ali', 'Gültekin', 2, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(4, 'Test', '1', 1, 1, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(5, 'demo', 'test trigger', 2, 0, '2014-05-22 11:29:08', '0000-00-00 00:00:00');

--
-- Tetikleyiciler `rehber`
--
DROP TRIGGER IF EXISTS `guncelleme_trigger`;
DELIMITER //
CREATE TRIGGER `guncelleme_trigger` BEFORE UPDATE ON `rehber`
 FOR EACH ROW SET New.degistirme_tarihi = NOW()
//
DELIMITER ;
DROP TRIGGER IF EXISTS `yaratma_tarihi_trigger`;
DELIMITER //
CREATE TRIGGER `yaratma_tarihi_trigger` BEFORE INSERT ON `rehber`
 FOR EACH ROW SET NEW.yaratma_tarihi = NOW()
//
DELIMITER ;

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `telefon`
--

CREATE TABLE IF NOT EXISTS `telefon` (
  `telefon_id` int(11) NOT NULL AUTO_INCREMENT,
  `telefon` varchar(15) NOT NULL,
  `rehber_id` int(11) NOT NULL,
  PRIMARY KEY (`telefon_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin5 AUTO_INCREMENT=6 ;

--
-- Tablo döküm verisi `telefon`
--

INSERT INTO `telefon` (`telefon_id`, `telefon`, `rehber_id`) VALUES
(1, '04535', 1),
(2, '5456', 1),
(3, '3565', 3),
(4, '34354', 2),
(5, '34243', 2);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
