﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using MySql.Data.MySqlClient;

namespace DB_Lib
{
    public class kullanici
    {
        public int kul_id;
        public string kul_adi;
        public string sifre;
        public string rol;
    }

    public class kullanici_islemleri
    {
        private MySqlConnection _cn;
        public kullanici bag_kul;
        public string hata; 

        public kullanici_islemleri()
        {
            _cn = new MySqlConnection(genel.cnt);
            bag_kul = new kullanici();
        }

        public bool login_kul(string kul_adi, string sifre)
        {
            try
            {
                _cn.Open();
                string sql = "SELECT kul_id, rol FROM kullanici WHERE kul_adi=@kul_adi and sifre=@sifre"; ;
                MySqlCommand _cmd = new MySqlCommand(sql, _cn);
                _cmd.Parameters.AddWithValue("@kul_adi", kul_adi);
                _cmd.Parameters.AddWithValue("@sifre", sifre);
                MySqlDataReader _dr = _cmd.ExecuteReader();

                if (_dr.HasRows)
                {
                    _dr.Read();
                    bag_kul.kul_id = _dr.GetInt32(0);
                    bag_kul.rol = _dr.GetString(1);
                    bag_kul.kul_adi = kul_adi;
                    _dr.Close();
                    _cn.Close();
                    return true;
                }
                else
                {
                    hata = "Kullanıcı adı veya şifreyi kontrol edin.";
                    _cn.Close();
                    return false;
                }

            }
            catch (Exception ex)
            {
                hata = ex.Message;
                _cn.Close();
                return false;
            }
 
        }
    }
}
