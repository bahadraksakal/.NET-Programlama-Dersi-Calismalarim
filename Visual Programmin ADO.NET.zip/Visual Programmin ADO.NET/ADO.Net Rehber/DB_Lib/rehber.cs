﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System.Data;
using MySql.Data.MySqlClient;

namespace DB_Lib
{
    public class rehber
    {
        private MySqlConnection _cn;

        public rehber()
        {
            _cn = new MySqlConnection(genel.cnt);
        }

        public DataTable Get_Rehber(string rol, string aranan)
        {
            try
            {
                string sql = "select r.rehber_id, r.ad, r.soyad, b.bolum_adi, r.silindimi from rehber r INNER JOIN bolum b ON b.bolum_id=r.bolum_id ";

                if (rol == "D" || rol == "G")
                {
                    sql += " WHERE (silindimi=false)";
                    if (aranan != "")
                        sql += " AND (r.ad like '%" + aranan + "%' OR r.soyad like '%" + aranan + "%' OR b.bolum_adi like '%" + aranan + "%')";
                }
                else
                {
                    if (aranan != "")
                        sql += " WHERE (r.ad like '%" + aranan + "%' OR r.soyad like '%" + aranan + "%' OR b.bolum_adi like '%" + aranan + "%')";
                }

                MySqlDataAdapter _da = new MySqlDataAdapter(sql, _cn);
                DataSet _ds = new DataSet();
                _da.Fill(_ds);

                return _ds.Tables[0];
            }
            catch
            {
                return null;
            } 
        }

        public int update_rehber(string ad, string soyad, int bolum_id, int rehber_id)
        {
            try
            {
                _cn.Open();
                string sql = "UPDATE Rehber SET ad=@ad, soyad=@soyad, bolum_id=@bolum_id WHERE rehber_id=@rehber_id";
                MySqlCommand _cmd = new MySqlCommand(sql, _cn);
                _cmd.Parameters.AddWithValue("@ad", ad);
                _cmd.Parameters.AddWithValue("@soyad", soyad);
                _cmd.Parameters.AddWithValue("@bolum_id", bolum_id);
                _cmd.Parameters.AddWithValue("@rehber_id", rehber_id);

                int s = _cmd.ExecuteNonQuery();
                return s;
            }
            catch (Exception ex)
            {
                _cn.Close();
                return 0;
            }
        }

        public int insert_rehber(string ad, string soyad, int bolum_id)
        {
            try
            {
                _cn.Open();
                string sql = "INSERT INTO Rehber(ad,soyad,bolum_id) VALUES(@ad,@soyad,@bolum_id)";
                MySqlCommand _cmd = new MySqlCommand(sql, _cn);
                _cmd.Parameters.AddWithValue("@ad", ad);
                _cmd.Parameters.AddWithValue("@soyad", soyad);
                _cmd.Parameters.AddWithValue("@bolum_id", bolum_id);

                int s = _cmd.ExecuteNonQuery();
                return s;
            }
            catch (Exception ex)
            {
                _cn.Close();
                return 0;
            }
        }

        public int sil_gecici_rehber(int rehber_id)
        {
            try
            {
                _cn.Open();
                string sql = "UPDATE Rehber SET silindimi=true WHERE rehber_id=@rehber_id";
                MySqlCommand _cmd = new MySqlCommand(sql, _cn);
                _cmd.Parameters.AddWithValue("@rehber_id", rehber_id);

                int s = _cmd.ExecuteNonQuery();
                return s;
            }
            catch (Exception ex)
            {
                _cn.Close();
                return 0;
            }
        }

        public int sil_kalici_rehber(int rehber_id)
        {
            try
            {
                _cn.Open();
                string sql = "DELETE FROM Rehber WHERE rehber_id=@rehber_id";
                MySqlCommand _cmd = new MySqlCommand(sql, _cn);
                _cmd.Parameters.AddWithValue("@rehber_id", rehber_id);

                int s = _cmd.ExecuteNonQuery();
                return s;
            }
            catch (Exception ex)
            {
                _cn.Close();
                return 0;
            }
        }
    }
}
