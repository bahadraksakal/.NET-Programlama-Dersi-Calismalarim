﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DB_Lib
{
    public static class genel
    {
        public static string cnt = "SERVER=localhost;DATABASE=telefonrehberi;UID=root;PASSWORD=";
    }
}
