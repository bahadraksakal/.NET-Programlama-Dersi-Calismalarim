﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using DB_Lib;

namespace ADO.Net_Rehber
{
    public partial class Rehber : Form
    {
        public AnaForm _af;

        public Rehber()
        {
            InitializeComponent();
        }

        private void BTN_Cancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void BTN_Kaydet_Click(object sender, EventArgs e)
        {
            rehber _r = new rehber();
            int s = 0;

            if (LBL_Rehber_id.Text == "-1")
            {
                s = _r.insert_rehber(TXT_Ad.Text, TXT_Soyad.Text, Convert.ToInt32(CB_Bolum.SelectedValue));

            }
            else
            {
                s = _r.update_rehber(TXT_Ad.Text, TXT_Soyad.Text, Convert.ToInt32(CB_Bolum.SelectedValue), Convert.ToInt32(LBL_Rehber_id.Text)); 
            }

            if (s > 0)
            {
                _af.Refresh_Rehber();
                this.Close();
            }
        }
    }
}
