﻿namespace ADO.Net_Rehber
{
    partial class AnaForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.LBL_Rol = new System.Windows.Forms.Label();
            this.dataGridView_Rehber = new System.Windows.Forms.DataGridView();
            this.Ad = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Soyad = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.bolum_adi = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.rehber_id = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.silindimi = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.dataGridView_Telefon = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.BTN_Deg_Reh = new System.Windows.Forms.Button();
            this.BTN_Ekle_Reh = new System.Windows.Forms.Button();
            this.BTN_Sil_Reh = new System.Windows.Forms.Button();
            this.TXT_Ara = new System.Windows.Forms.TextBox();
            this.BTN_Sorgu = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_Rehber)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_Telefon)).BeginInit();
            this.SuspendLayout();
            // 
            // LBL_Rol
            // 
            this.LBL_Rol.AutoSize = true;
            this.LBL_Rol.Location = new System.Drawing.Point(549, 9);
            this.LBL_Rol.Name = "LBL_Rol";
            this.LBL_Rol.Size = new System.Drawing.Size(23, 13);
            this.LBL_Rol.TabIndex = 0;
            this.LBL_Rol.Text = "Rol";
            // 
            // dataGridView_Rehber
            // 
            this.dataGridView_Rehber.AllowUserToAddRows = false;
            this.dataGridView_Rehber.AllowUserToDeleteRows = false;
            this.dataGridView_Rehber.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView_Rehber.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Ad,
            this.Soyad,
            this.bolum_adi,
            this.rehber_id,
            this.silindimi});
            this.dataGridView_Rehber.Location = new System.Drawing.Point(12, 74);
            this.dataGridView_Rehber.Name = "dataGridView_Rehber";
            this.dataGridView_Rehber.ReadOnly = true;
            this.dataGridView_Rehber.Size = new System.Drawing.Size(636, 150);
            this.dataGridView_Rehber.TabIndex = 1;
            this.dataGridView_Rehber.RowEnter += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView_Rehber_RowEnter);
            // 
            // Ad
            // 
            this.Ad.DataPropertyName = "Ad";
            this.Ad.HeaderText = "Ad";
            this.Ad.Name = "Ad";
            this.Ad.ReadOnly = true;
            this.Ad.Width = 150;
            // 
            // Soyad
            // 
            this.Soyad.DataPropertyName = "Soyad";
            this.Soyad.HeaderText = "Soyad";
            this.Soyad.Name = "Soyad";
            this.Soyad.ReadOnly = true;
            this.Soyad.Width = 150;
            // 
            // bolum_adi
            // 
            this.bolum_adi.DataPropertyName = "bolum_adi";
            this.bolum_adi.HeaderText = "Bölüm Adı";
            this.bolum_adi.Name = "bolum_adi";
            this.bolum_adi.ReadOnly = true;
            this.bolum_adi.Width = 200;
            // 
            // rehber_id
            // 
            this.rehber_id.DataPropertyName = "rehber_id";
            this.rehber_id.HeaderText = "id";
            this.rehber_id.Name = "rehber_id";
            this.rehber_id.ReadOnly = true;
            this.rehber_id.Width = 20;
            // 
            // silindimi
            // 
            this.silindimi.DataPropertyName = "silindimi";
            this.silindimi.HeaderText = "Durum";
            this.silindimi.Name = "silindimi";
            this.silindimi.ReadOnly = true;
            this.silindimi.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.silindimi.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.silindimi.Width = 50;
            // 
            // dataGridView_Telefon
            // 
            this.dataGridView_Telefon.AllowUserToAddRows = false;
            this.dataGridView_Telefon.AllowUserToDeleteRows = false;
            this.dataGridView_Telefon.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView_Telefon.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1});
            this.dataGridView_Telefon.Location = new System.Drawing.Point(12, 279);
            this.dataGridView_Telefon.Name = "dataGridView_Telefon";
            this.dataGridView_Telefon.ReadOnly = true;
            this.dataGridView_Telefon.Size = new System.Drawing.Size(579, 150);
            this.dataGridView_Telefon.TabIndex = 2;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.DataPropertyName = "telefon";
            this.dataGridViewTextBoxColumn1.HeaderText = "Telefon";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.ReadOnly = true;
            this.dataGridViewTextBoxColumn1.Width = 150;
            // 
            // BTN_Deg_Reh
            // 
            this.BTN_Deg_Reh.Location = new System.Drawing.Point(287, 45);
            this.BTN_Deg_Reh.Name = "BTN_Deg_Reh";
            this.BTN_Deg_Reh.Size = new System.Drawing.Size(75, 23);
            this.BTN_Deg_Reh.TabIndex = 3;
            this.BTN_Deg_Reh.Text = "Değiştir";
            this.BTN_Deg_Reh.UseVisualStyleBackColor = true;
            this.BTN_Deg_Reh.Click += new System.EventHandler(this.BTN_Deg_Reh_Click);
            // 
            // BTN_Ekle_Reh
            // 
            this.BTN_Ekle_Reh.Location = new System.Drawing.Point(206, 45);
            this.BTN_Ekle_Reh.Name = "BTN_Ekle_Reh";
            this.BTN_Ekle_Reh.Size = new System.Drawing.Size(75, 23);
            this.BTN_Ekle_Reh.TabIndex = 4;
            this.BTN_Ekle_Reh.Text = "Ekle";
            this.BTN_Ekle_Reh.UseVisualStyleBackColor = true;
            this.BTN_Ekle_Reh.Click += new System.EventHandler(this.BTN_Ekle_Reh_Click);
            // 
            // BTN_Sil_Reh
            // 
            this.BTN_Sil_Reh.Location = new System.Drawing.Point(368, 45);
            this.BTN_Sil_Reh.Name = "BTN_Sil_Reh";
            this.BTN_Sil_Reh.Size = new System.Drawing.Size(75, 23);
            this.BTN_Sil_Reh.TabIndex = 5;
            this.BTN_Sil_Reh.Text = "Sil";
            this.BTN_Sil_Reh.UseVisualStyleBackColor = true;
            this.BTN_Sil_Reh.Click += new System.EventHandler(this.BTN_Sil_Reh_Click);
            // 
            // TXT_Ara
            // 
            this.TXT_Ara.Location = new System.Drawing.Point(12, 6);
            this.TXT_Ara.Name = "TXT_Ara";
            this.TXT_Ara.Size = new System.Drawing.Size(220, 20);
            this.TXT_Ara.TabIndex = 6;
            // 
            // BTN_Sorgu
            // 
            this.BTN_Sorgu.Location = new System.Drawing.Point(238, 3);
            this.BTN_Sorgu.Name = "BTN_Sorgu";
            this.BTN_Sorgu.Size = new System.Drawing.Size(75, 23);
            this.BTN_Sorgu.TabIndex = 7;
            this.BTN_Sorgu.Text = "Sorgu";
            this.BTN_Sorgu.UseVisualStyleBackColor = true;
            this.BTN_Sorgu.Click += new System.EventHandler(this.BTN_Sorgu_Click);
            // 
            // AnaForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(696, 456);
            this.Controls.Add(this.BTN_Sorgu);
            this.Controls.Add(this.TXT_Ara);
            this.Controls.Add(this.BTN_Sil_Reh);
            this.Controls.Add(this.BTN_Ekle_Reh);
            this.Controls.Add(this.BTN_Deg_Reh);
            this.Controls.Add(this.dataGridView_Telefon);
            this.Controls.Add(this.dataGridView_Rehber);
            this.Controls.Add(this.LBL_Rol);
            this.Name = "AnaForm";
            this.Text = "AnaForm";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.AnaForm_FormClosed);
            this.Load += new System.EventHandler(this.AnaForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_Rehber)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_Telefon)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        public System.Windows.Forms.Label LBL_Rol;
        private System.Windows.Forms.DataGridView dataGridView_Rehber;
        private System.Windows.Forms.DataGridView dataGridView_Telefon;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.Button BTN_Deg_Reh;
        private System.Windows.Forms.Button BTN_Ekle_Reh;
        private System.Windows.Forms.Button BTN_Sil_Reh;
        private System.Windows.Forms.DataGridViewTextBoxColumn Ad;
        private System.Windows.Forms.DataGridViewTextBoxColumn Soyad;
        private System.Windows.Forms.DataGridViewTextBoxColumn bolum_adi;
        private System.Windows.Forms.DataGridViewTextBoxColumn rehber_id;
        private System.Windows.Forms.DataGridViewCheckBoxColumn silindimi;
        private System.Windows.Forms.TextBox TXT_Ara;
        private System.Windows.Forms.Button BTN_Sorgu;

    }
}