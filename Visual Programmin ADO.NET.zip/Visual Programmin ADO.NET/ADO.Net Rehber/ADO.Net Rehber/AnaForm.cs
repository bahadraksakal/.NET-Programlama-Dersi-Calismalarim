﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using DB_Lib;

namespace ADO.Net_Rehber
{
    public partial class AnaForm : Form
    {
        public Form1 login_form;

        public AnaForm()
        {
            InitializeComponent();
        }

        public void Refresh_Rehber()
        {
            rehber _r = new rehber();
            dataGridView_Rehber.DataSource = _r.Get_Rehber(LBL_Rol.Text, TXT_Ara.Text);
        }

        private void gorunum()
        {
            if (LBL_Rol.Text == "D")
            {
                BTN_Ekle_Reh.Visible = false;
                dataGridView_Rehber.Columns["silindimi"].Visible = false;
            }
            else if (LBL_Rol.Text == "G")
            {
                BTN_Deg_Reh.Visible = false;
                BTN_Ekle_Reh.Visible = false;
                BTN_Sil_Reh.Visible = false;
                dataGridView_Rehber.Columns["silindimi"].Visible = false;
            }
 
        }

        private void AnaForm_Load(object sender, EventArgs e)
        {
            Refresh_Rehber();

            gorunum();
        }

        private void AnaForm_FormClosed(object sender, FormClosedEventArgs e)
        {
            login_form.Visible = true;
        }

        private void dataGridView_Rehber_RowEnter(object sender, DataGridViewCellEventArgs e)
        {
            string rehber_id = dataGridView_Rehber.Rows[e.RowIndex].Cells["rehber_id"].Value.ToString();
            telefon _t = new telefon();
            dataGridView_Telefon.DataSource = _t.Get_Telefon(rehber_id);
        }

        private void BTN_Deg_Reh_Click(object sender, EventArgs e)
        {
            Rehber _r_form = new Rehber();
            _r_form.TXT_Ad.Text = dataGridView_Rehber.CurrentRow.Cells["ad"].Value.ToString();
            _r_form.TXT_Soyad.Text = dataGridView_Rehber.CurrentRow.Cells["soyad"].Value.ToString();
            _r_form.LBL_Rehber_id.Text = dataGridView_Rehber.CurrentRow.Cells["rehber_id"].Value.ToString();

            bolum _b = new bolum();
            _r_form.CB_Bolum.DataSource = _b.Get_bolum();
            _r_form.CB_Bolum.DisplayMember = "bolum_adi";
            _r_form.CB_Bolum.ValueMember = "bolum_id";
            _r_form.CB_Bolum.Text = dataGridView_Rehber.CurrentRow.Cells["bolum_adi"].Value.ToString();
            
            //refresh olsun diye anaform ile bağlantı
            _r_form._af = this;

            _r_form.ShowDialog();
        }

        private void BTN_Ekle_Reh_Click(object sender, EventArgs e)
        {
            Rehber _r_form = new Rehber();

            bolum _b = new bolum();
            _r_form.CB_Bolum.DataSource = _b.Get_bolum();
            _r_form.CB_Bolum.DisplayMember = "bolum_adi";
            _r_form.CB_Bolum.ValueMember = "bolum_id";

            //refresh olsun diye anaform ile bağlantı
            _r_form._af = this;

            //insert mi? (-1) update mi? (>0)
            _r_form.LBL_Rehber_id.Text = "-1";
            _r_form.ShowDialog();

        }

        private void BTN_Sil_Reh_Click(object sender, EventArgs e)
        {
            rehber _r = new rehber();
            int rehber_id = Convert.ToInt32(dataGridView_Rehber.CurrentRow.Cells["rehber_id"].Value.ToString());

            if (LBL_Rol.Text == "A")
                _r.sil_kalici_rehber(rehber_id);
            else if (LBL_Rol.Text == "D")
                _r.sil_gecici_rehber(rehber_id);

            Refresh_Rehber();
        }

        private void BTN_Sorgu_Click(object sender, EventArgs e)
        {
            Refresh_Rehber();
        }

       
    }
}
