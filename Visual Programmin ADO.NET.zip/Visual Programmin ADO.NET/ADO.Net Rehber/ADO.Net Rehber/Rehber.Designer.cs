﻿namespace ADO.Net_Rehber
{
    partial class Rehber
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.TXT_Soyad = new System.Windows.Forms.TextBox();
            this.TXT_Ad = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.CB_Bolum = new System.Windows.Forms.ComboBox();
            this.BTN_Cancel = new System.Windows.Forms.Button();
            this.BTN_Kaydet = new System.Windows.Forms.Button();
            this.LBL_Rehber_id = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // TXT_Soyad
            // 
            this.TXT_Soyad.Location = new System.Drawing.Point(116, 43);
            this.TXT_Soyad.Name = "TXT_Soyad";
            this.TXT_Soyad.Size = new System.Drawing.Size(243, 25);
            this.TXT_Soyad.TabIndex = 8;
            // 
            // TXT_Ad
            // 
            this.TXT_Ad.Location = new System.Drawing.Point(116, 12);
            this.TXT_Ad.Name = "TXT_Ad";
            this.TXT_Ad.Size = new System.Drawing.Size(243, 25);
            this.TXT_Ad.TabIndex = 7;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(18, 48);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(43, 20);
            this.label2.TabIndex = 6;
            this.label2.Text = "Soyad";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(18, 17);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(23, 20);
            this.label1.TabIndex = 5;
            this.label1.Text = "Ad";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(18, 80);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(45, 20);
            this.label3.TabIndex = 10;
            this.label3.Text = "Bölüm";
            // 
            // CB_Bolum
            // 
            this.CB_Bolum.FormattingEnabled = true;
            this.CB_Bolum.Location = new System.Drawing.Point(116, 80);
            this.CB_Bolum.Name = "CB_Bolum";
            this.CB_Bolum.Size = new System.Drawing.Size(243, 28);
            this.CB_Bolum.TabIndex = 11;
            // 
            // BTN_Cancel
            // 
            this.BTN_Cancel.Location = new System.Drawing.Point(199, 128);
            this.BTN_Cancel.Name = "BTN_Cancel";
            this.BTN_Cancel.Size = new System.Drawing.Size(160, 32);
            this.BTN_Cancel.TabIndex = 12;
            this.BTN_Cancel.Text = "Vazgeç";
            this.BTN_Cancel.UseVisualStyleBackColor = true;
            this.BTN_Cancel.Click += new System.EventHandler(this.BTN_Cancel_Click);
            // 
            // BTN_Kaydet
            // 
            this.BTN_Kaydet.Location = new System.Drawing.Point(22, 128);
            this.BTN_Kaydet.Name = "BTN_Kaydet";
            this.BTN_Kaydet.Size = new System.Drawing.Size(160, 32);
            this.BTN_Kaydet.TabIndex = 9;
            this.BTN_Kaydet.Text = "Kaydet";
            this.BTN_Kaydet.UseVisualStyleBackColor = true;
            this.BTN_Kaydet.Click += new System.EventHandler(this.BTN_Kaydet_Click);
            // 
            // LBL_Rehber_id
            // 
            this.LBL_Rehber_id.AutoSize = true;
            this.LBL_Rehber_id.Location = new System.Drawing.Point(-3, 161);
            this.LBL_Rehber_id.Name = "LBL_Rehber_id";
            this.LBL_Rehber_id.Size = new System.Drawing.Size(0, 20);
            this.LBL_Rehber_id.TabIndex = 13;
            // 
            // Rehber
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(395, 178);
            this.Controls.Add(this.LBL_Rehber_id);
            this.Controls.Add(this.BTN_Cancel);
            this.Controls.Add(this.CB_Bolum);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.BTN_Kaydet);
            this.Controls.Add(this.TXT_Soyad);
            this.Controls.Add(this.TXT_Ad);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Font = new System.Drawing.Font("Arial Narrow", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.Name = "Rehber";
            this.Text = "Rehber";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button BTN_Cancel;
        private System.Windows.Forms.Button BTN_Kaydet;
        public System.Windows.Forms.TextBox TXT_Soyad;
        public System.Windows.Forms.TextBox TXT_Ad;
        public System.Windows.Forms.ComboBox CB_Bolum;
        public System.Windows.Forms.Label LBL_Rehber_id;
    }
}