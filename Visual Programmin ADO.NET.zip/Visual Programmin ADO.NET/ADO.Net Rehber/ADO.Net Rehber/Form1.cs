﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

//DB_Lib reference bölümünde olmalı
using DB_Lib;

namespace ADO.Net_Rehber
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            kullanici_islemleri _ki = new kullanici_islemleri();
            bool sonuc = _ki.login_kul(TXT_kul_adi.Text, TXT_Sifre.Text);

            if (sonuc)
            {
                this.Visible = false; //Burdaki form
                TXT_kul_adi.Text = "";
                TXT_Sifre.Text = "";
                AnaForm _af = new AnaForm();
                _af.login_form = this; //Buradaki form'un adresini gönderdi.
                kullanici _kul = _ki.bag_kul;
                _af.LBL_Rol.Text = _kul.rol;
                _af.ShowDialog();                
                
                LBL_Hata.Text = "OK";
            }
            else
            {                
                TXT_Sifre.Text = "";
                LBL_Hata.Text = _ki.hata;
            }

        }
    }
}
