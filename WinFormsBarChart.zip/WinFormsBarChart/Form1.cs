using System.Security.Cryptography.X509Certificates;

namespace WinFormsBarChart
{
    public partial class Form1 : Form
    {
        private Graphics g;
        private int x = 90, y=120;
        private int maximumPixelY = 200;
        private int maximumDeger = 100;
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string[] degerler = textBox1.Text.Split(",");
            Bar[] bars = new Bar[degerler.Length];
            Graphics g = panel1.CreateGraphics();
            g.Clear(Color.White);

            for(int i= 0; i < degerler.Length; i++)
            {
                int deger = Int32.Parse(degerler[i].Trim());
                bars[i] = new Bar(x, y, deger, i);
                bars[i].hesapla(maximumDeger, maximumPixelY);
                bars[i].ciz(g);
            }
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {
           
        }
    }
}