﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WinFormsBarChart
{
    internal class Bar
    {
        Color[] colors = new Color[] {Color.Blue, Color.Red, Color.Brown};
        Color myColor;
        int index = 0;
        int x, y;
        int deger;
        int boslukx = 10;
        int hesaplananx, hesaplanany;
        int pixelSizeY = 0, pixelSizeX = 30;
        public Bar(int x, int y, int deger, int index)
        {
            this.deger = deger;
            this.index = index;
            this.x = x; this.y = y;
            
            this.hesaplananx = x + (index) * (pixelSizeX+boslukx);
            this.myColor = colors[index];            
        }

        public void hesapla(int maximumDeger, int maximumPixelUzunluk)
        {
            double oranti = deger * ((double) maximumPixelUzunluk) / maximumDeger;
            pixelSizeY = (int) Math.Floor(oranti);
            hesaplanany = y + maximumPixelUzunluk - pixelSizeY;
        }

        public void ciz(Graphics g)
        {
            Point p = new Point(hesaplananx, hesaplanany);
            Size size = new Size(new Point(pixelSizeX, pixelSizeY));
            //Pen pen = new Pen(new SolidBrush(myColor), 3);
            g.FillRectangle(new SolidBrush(myColor), new Rectangle(p, size));
            
        }
        
    }
}
