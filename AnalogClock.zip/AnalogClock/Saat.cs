﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ScrollBar;

namespace AnalogClock
{
    internal class Saat
    {
        public int merkez_x, merkez_y;
        public int cap; 
        public int shift = 10;

        public Cubuk saniyeCubuk, yelkovanCubuk, akrepCubuk;
        public int saat, dakika, saniye;
        public Graphics g;

        public Saat(Graphics g, int merkez_x, int merkez_y, int cap)
        {
            this.g = g;
            this.merkez_x = merkez_x;
            this.merkez_y = merkez_y;
            this.cap = cap;

            saniyeCubuk = new Cubuk(merkez_x + shift, merkez_y + shift, cap - 25);
            yelkovanCubuk = new Cubuk(merkez_x + 10, merkez_y + 10 , cap - 30);
            akrepCubuk = new Cubuk(merkez_x + 10, merkez_y + 10, cap - 45);

            saniyeCubuk.sifirla();
            yelkovanCubuk.sifirla();
            akrepCubuk.sifirla();
        }

       

        public void ciz()
        {
                   
            g.Clear(Color.White);
            int three3Box_x = merkez_x + (cap - 5);
            int nine9Box_x = merkez_x-(cap-5);
            int six6Box_x = merkez_x-5;
            int twelve12Box_x = merkez_x-5;

            int three3Box_y = merkez_y - 5;
            int nine9Box_y = merkez_y-5;
            int six6Box_y = merkez_y + (cap-5);
            int twelve12Box_y = merkez_y - (cap-5);

            float fontSize = cap / 10;
            Font drawFont = new System.Drawing.Font("Arial", 16);
            Brush brush = new System.Drawing.SolidBrush(System.Drawing.Color.Black);
            Pen pen = new Pen(Color.Black, 2);

            int cerceve = cap + shift;

            g.DrawEllipse(pen, merkez_x - cap, merkez_y - cap, 2 * cerceve, 2 * cerceve);
            g.DrawString("12", drawFont, brush, twelve12Box_x, twelve12Box_y);
            g.DrawString("3", drawFont, brush, three3Box_x, three3Box_y);
            g.DrawString("6", drawFont, brush, six6Box_x, six6Box_y);
            g.DrawString("9", drawFont, brush, nine9Box_x, nine9Box_y);

            Pen penSaniye = new Pen(Color.Red, 1);
            Pen penYelkovan = new Pen(Color.Black, 3);
            Pen penAkrep = new Pen(Color.RosyBrown, 5);

            saniyeCubuk.ciz(g, penSaniye);
            yelkovanCubuk.ciz(g, penYelkovan);
            akrepCubuk.ciz(g, penAkrep);

        }


        public void tik(int saat, int dakika, int saniye)
        {
            if (this.saniye != saniye)
            {
                int derece = 6 * saniye;
                saniyeCubuk.dondur(derece);
                this.saniye = saniye;
            }

            if (this.dakika!= dakika)
            {
                int derece = 6 * dakika;
                yelkovanCubuk.dondur(derece);
                this.dakika = dakika;
            }


            if (this.saat != saat)
            {
                int derece = 30 * saat % 360;
                akrepCubuk.dondur(derece);
                this.saat = saat;
            }
        }
    }

    internal class Cubuk
    {
        public int merkez_x, merkez_y;
        public int uc_x, uc_y;
        public int uzunluk;

        public Cubuk(int merkez_x, int merkez_y, int uzunluk)
        {
            this.merkez_x = merkez_x;
            this.merkez_y = merkez_y;
            this.uzunluk = uzunluk;  
        }

        public void dondur(int derece)
        {
           double piderece = ((derece-90) * Math.PI / 180);
           uc_x = (int)(merkez_x + Math.Cos(piderece) * uzunluk);
           uc_y = (int)(merkez_y + Math.Sin(piderece) * uzunluk);
         
        }

        public void sifirla()
        {
            uc_x = merkez_x + 0;
            uc_y = merkez_y - uzunluk;
        }

        public void ciz(Graphics g, Pen p)
        {
            g.DrawLine(p, new Point(merkez_x, merkez_y), new Point(uc_x, uc_y));
        }
    }
}
