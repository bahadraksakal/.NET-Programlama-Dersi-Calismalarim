namespace AnalogClock
{
    public partial class Form1 : Form
    {
        private Saat saat;
        private Bitmap bitmap;
        public Form1()
        {
            InitializeComponent();
   
        }
        private void Form1_Paint(object sender, PaintEventArgs e)
        {
            ciz(panel1.CreateGraphics());
        }

        public void ciz(Graphics g)
        {
            int height = panel1.Size.Height;
            int width = panel1.Size.Width;
                
            int merkez_y = height / 2;
            int merkez_x = width / 2 - 10;
            int ycap = width / 4;

            saat = new Saat(g, merkez_x, merkez_y, ycap);
            saat.ciz();
            timer1.Start();
        }

        public void tiktok()
        {
            int hour = DateTime.Now.Hour;
            int dakika = DateTime.Now.Minute;
            int saniye = DateTime.Now.Second;

            saat.tik(hour, dakika, saniye);
            saat.ciz();            
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            tiktok();           
        }



        private void panel1_MouseClick(object sender, MouseEventArgs e)
        { }


    }
}