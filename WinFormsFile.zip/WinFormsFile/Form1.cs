namespace WinFormsFile
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        public string textDosyaOku()
        {
            string file = @"C:\\Users\\hayri.agun\\Desktop\\file1.txt";
            string text = "";
            string line = "";
            using (StreamReader sr = new StreamReader(file))
            {
                
                while(line != null)
                {
                    text = text + line;
                    line = sr.ReadLine() + "\n";
                }
            }

            return text;
        }

        public void textDosyaYaz(string text)
        {
            string file = @"C:\\Users\\hayri.agun\\Desktop\\file2.txt";
            
            string line = "";
            using (StreamWriter sr = new StreamWriter(file))
            {

                sr.WriteLine(text);
            }
            
        }


        private void button1_Click(object sender, EventArgs e)
        {
            string text = textDosyaOku();
            textDosyaYaz(text);
        }
    }
}